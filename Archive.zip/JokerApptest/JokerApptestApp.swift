//
//  JokerApptestApp.swift
//  JokerApptest
//
//  Created by Zo on 11/24/23.
//

import SwiftUI

@main
struct JokerApptestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
